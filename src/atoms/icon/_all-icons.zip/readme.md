# Icons

Icons are available as an svg sprite, as individual svg files and as a zip containing all icons and the svg sprite.
